// ---------------- STICKY NAVBAR ACTIVE LINK ----------------
const navLinks = document.querySelectorAll('nav a');
const sections = document.querySelectorAll('section');

window.addEventListener('scroll', () => {
  let current = '';
  sections.forEach(section => {
    const sectionTop = section.offsetTop - 70;
    if (pageYOffset >= sectionTop) {
      current = section.getAttribute('id');
    }
  });

  navLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href').includes(current)) {
      link.classList.add('active');
    }
  });
});

// ---------------- HERO TEXT ANIMATION ----------------
document.addEventListener('DOMContentLoaded', () => {
  const heroHeading = document.querySelector('.hero h1');
  if (heroHeading) {
    setTimeout(() => {
      heroHeading.classList.add('show');
    }, 300);
  }
});

// ---------------- SCROLL ANIMATIONS ----------------
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('show');
    }
  });
}, { threshold: 0.3 });

document.querySelectorAll('article').forEach(article => {
  observer.observe(article);
});
